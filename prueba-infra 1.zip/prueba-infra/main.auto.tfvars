prefix = "app1-p-g-001"
# subscription_id = Rellenar con la suscripcion que es.
tags  = {
  "environment" = "test"
  "user" = "crodriguez"
  "region" = "Germany West Central"
}
mg_group = "mg-sdbx-p-g-000"
address_space = ["10.216.36.0/27"]
address_prefixes = ["10.216.36.0/28"]