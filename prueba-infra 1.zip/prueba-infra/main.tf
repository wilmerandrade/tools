resource "azurerm_resource_group" "example" {
  name     = "rg-${var.prefix}"
  location = "Germany West Central"
  tags = var.tags
}
resource "azurerm_resource_group" "example2" {
  name     = "rg-app1-002"
  location = "Germany West Central"
  tags = var.tags
}

resource "azurerm_network_security_group" "example" {
  name                = "NSG-${var.prefix}"
  location            = azurerm_resource_group.example.location
  resource_group_name = azurerm_resource_group.example.name

  tags = var.tags
}

resource "azurerm_virtual_network" "main_network" {
  name                = "vn-${var.prefix}"
  address_space       = var.address_space
  location            = azurerm_resource_group.example.location
  resource_group_name = azurerm_resource_group.example.name
}

resource "azurerm_subnet" "internal" {
  name                 = "sn-${var.prefix}"
  resource_group_name  = azurerm_resource_group.example.name
  virtual_network_name = azurerm_virtual_network.main_network.name
  address_prefixes     = var.address_prefixes
}

resource "azurerm_network_interface" "main_interface" {
  name                = "${var.prefix}-nic"
  location            = azurerm_resource_group.example.location
  resource_group_name = azurerm_resource_group.example2.name

  ip_configuration {
    name                          = "testconfiguration1"
    subnet_id                     = azurerm_subnet.internal.id
    private_ip_address_allocation = "Dynamic"
  }
}

resource "azurerm_virtual_machine" "main" {
  name                  = "vn-${var.prefix}"
  location              = azurerm_resource_group.example2.location
  resource_group_name   = azurerm_resource_group.example2.name
  network_interface_ids = [azurerm_network_interface.main_interface.id]
  vm_size               = "Standard_DS1_v2"
  delete_os_disk_on_termination = true
  delete_data_disks_on_termination = true

  storage_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts"
    version   = "latest"
  }
  storage_os_disk {
    name              = "myosdisk1"
    caching           = "ReadWrite"
    create_option     = "FromImage"
    managed_disk_type = "Standard_LRS"
  }
  os_profile {
    computer_name  = "hostname"
    admin_username = "testadmin"
    admin_password = "Password1234!"
  }
  os_profile_linux_config {
    disable_password_authentication = false
  }
  tags = var.tags
}