variable "prefix" {
  type = string
  default = "prueba"
}

variable "tenant_id" {
    type = string
}

variable "subscription_id" {
    type = string
}
/*
variable "billing_account_id" {
    type = string
}

variable "enrollment_account_id" {
    type = string
}
*/
variable "client_id" {
    type = string
}

variable "client_secret" {
    type = string
}

variable "tags" {
    type = map(string)
}

variable "address_space" {
    type = list(string)
}

variable "address_prefixes" {
    type = list(string)
}
variable "mg_group" {
    type = string
  
}